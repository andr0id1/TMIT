<?php session_start();
/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 14.03.17
 * Time: 21:16
 */

require("../inc/includes.php");


?>
<!DOCTYPE html>
<html lang="de">
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar-fixed-side.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
    <link href="../css/buttons.css" rel="stylesheet" />
    <link href="../css/tables.css" rel="stylesheet" />
    <link href="../css/equaly-hights.css" rel="stylesheet" />
</head>
<body>


<div class="container-fluid">
    <div class="row" style="background-color: lightgray">
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-5">
            <a href="../www/index.php" title="Zum Index">
                <img src="../bilder/logo_RBZ.png" class="center-block" style="width: 10rem; height: auto; display: block; margin-top: 1rem;">
            </a>
        </div>
        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-7">
            <h1>
                Krasse Sachen
                <br>
                <small>
                    Lehrer kram
                </small>
            </h1>
        </div>
        <div class="col-lg-2 col-md-3 btn-abs col-sm-3 col-xs-12">
            <div style="margin-top: 1rem">
                <a class="btn btn-primary btn-sm sharp btn-block">Logout</a>
                <a class="btn btn-primary btn-sm sharp btn-block">Heeeeey</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            content
        </div>
    </div>


</div>


<footer class="footer">
    <div class="container-fluid">
            <?php
            $datum = date("d.m.Y H:i");
            echo"$datum";
            ?>

    </div>
</footer>

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</body>
</html>


<?php
// Datenbankverbindungen
$mysqlServer	= "localhost";
$mysqlUser		= "TMIT";
$mysqlPass		= "TMIT123";
$mysqlDB		= "TMIT";
?>


<?php
function echo_r($x)
{
	echo '<pre style="color:red">'.print_r($x,true).'</pre>';
}




	//function passwort_korrekt($uname,$pw)
	//{		global $db;
	//		
	//		$sql="SELECT password From nutzer WHERE Name= '$uname'";
	//		
	//		if($db_ergebnis=$db->query($sql))
	//		{ 
	//			echo_r ($db_ergebnis);
	//			echo_r ($pw);
	//			
	//			
	//			
	//			if ($pw == $db_ergebnis[0]['password'])
	//			{
	//				echo "hat geklappt!";
    //
	//				return true;
	//			}
	//			
	//			else 
	//				return false;
	//		
	//		}
	//}
	
	
	function passwort_korrekt($uname,$pw)
	{	
		global $db;
		echo_r ("Pruefe PW: Übergeben: $pw");
		$sql="SELECT password FROM nutzer WHERE email='$uname'";
		echo "$sql";
		echo_r ($uname,$pw);
		if($db_ergebnis=$db-> query($sql))
			{  
				echo "$pw";
				echo_r($db_ergebnis);
				if (password_verify($pw,$db_ergebnis[0]['password']))
				{
					return true;
				}
				else
					return false;
			}
	}
   
   
   
   
    function loginformular_ausgeben($wohin_action)
    {     echo " <h3>Kein Nutzer eingelogged, <br>
				  Sie können sich <a href='register2.php'> hier </a> registrieren</a>
		 
		         Bitte loggen Sie sich ein:<br>
		         <br> Login:   </h3><br>";
		         
   		  echo '  <form action="'.$wohin_action.'" method="post">
				EMail: <br>
				<input type="text" name="nutzer_name"> <br>
				Password: <br>
				<input type="password" name="nutzer_passwort"> <br><br>
				<input type="submit"value="abschicken">
			   </form>';
     }

	 function Email_vorhanden($daten)		// von Bo geschrieben
	 {
		 global $db;
		 $email = $daten['nutzer_Email'];
		 
		 $sql1= mysql_query("SELECT id FROM nutzer WHERE email= '$email'");		// sucht die Verwendete Email in der Datenbank
		 
		 if(mysql_num_rows($sql1)>=1)		// gibt aus ob Email bereits vorhanden oder nicht
			{ 
			return false;	
			}
			else
			{
			return true;
			}
	 }
	 function Geburtsdatum($daten)			// von Bo eingefügt
	 {
		$geb= new DateTime($daten['geburtsdatum']);			// übernimmt das Geburtsdatum aus der Eingabe
		$heute = new DateTime (date("Y-m-d"));				// holt das Datum von heute
		$differenz = $geb->diff($heute);					// bildet die Differenz zwischen dem Geburtsdatum und heute
		$alter=$differenz->format('%y');			// Formt die Differenz in eine Jahresausgabe um

		if ($alter >= 18 && $alter <=100)			// Vergleicht, ob das Alter größer als 18 ist und geringer als 100 ist
		{
			return true;
		}
		else
		{
			return false;
		}
		
		 
	 }
	 
	 
 function nutzer_eintragen_db($daten)
 {global $db;
$test = $daten['nutzer_passwort'];


	$passcode=password_hash($daten['nutzer_passwort'], PASSWORD_BCRYPT);
	$sql= "INSERT INTO nutzer (id, vorname, nachname, password, email, geburtsdatum)
		  VALUES (NULL, '$daten[nutzer_Vorname]','$daten[nutzer_Nachname]', '$passcode', '$daten[nutzer_Email]', '$daten[geburtsdatum]')";
	if($db->query($sql))
	  return true; //hat geklappt
	else
	{
		echo "Fehler2";
	return false; //Fehler		
	}
	
}

	
	
		
			
			
?>

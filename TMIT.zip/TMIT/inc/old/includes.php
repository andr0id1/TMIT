<?php 

// Starte Session 

@session_start();


// Pfad zum Basis-Verzeichnis der Web-Anwendung

$basedir = dirname(__FILE__)."/..";

// Include-Dateien


require($basedir."/inc/dbconfig.php");
require($basedir."/inc/db.class.php");
require($basedir."/inc/hilfsfunktionen.php");
require($basedir."/inc/funktionen.php");
require($basedir."/inc/hilfsfunktion2.php");

//require($basedir."/inc/passwd_check.js");

// Stelle Datenbankverbindung her 
// Verbindungsdaten stehen in dbconfig.php 

$db = new db();
$db->connect($mysqlServer, $mysqlUser, $mysqlPass, $mysqlDB);


?>

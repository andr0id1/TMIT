<?php
// Datenbankverbindungen

/*
$mysqlServer	= "localhost";
$mysqlUser		= "root";
$mysqlPass		= "";
$mysqlDB		= "db2802874";
*/
$mysqlServer	= "rdbms.strato.de";
$mysqlUser		= "U2802874";
$mysqlPass		= "3ck3n3rmYSqL2016-1!";
$mysqlDB		= "DB2802874";


?>

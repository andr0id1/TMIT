
<?php

	
	
function Lehrer_vorhanden($data)
	{
		global $db;
		$wins = $data['wins'];
		$sql='SELECT wins FROM lehrer WHERE wins= "'.$wins.'" ';
		
			($db_ergebnis=$db->query($sql));
			if (isset ($db_ergebnis[0] ))
			{
			 return false;
			}
			else
			{
			return true;
			}
	}

	
	
	
	
	
function lehrer_eintragen_db($data)
	{   
		global $db; //Wir verwenden die Standard-DB
		
	$wins= $data['wins'];
	$l_level= $data['l_level'];
	$l_pw= $data['l_pw'];
	$l_pw = mysqli_real_escape_string($db->con, $data['l_pw']);
	$l_aktiv= $data['l_aktiv'];
	$l_email=$data['email'];
	
		$sql = 'insert into lehrer (lehrer_id,wins,email,level,lpw,aktiv) values (NULL,"'.$wins.'","'.$l_email.'","'.$l_level.'","'.$l_pw.'","'.$l_aktiv.'")';
			
			
			if($db->query($sql))
			{
			return true;
			}
			else
			{
			return false;
			}
	}		
			
			
			
function lehrer_updaten_db($data)
	{   
		global $db; //Wir verwenden die Standard-DB
		
		$lehrer_id=$data['id'];
		
	$wins= $data['wins'];
	$l_level= $data['l_level'];
	$l_pw= $data['l_pw'];
	$l_pw = mysqli_real_escape_string($db->con, $data['l_pw']);
	$l_aktiv= $data['l_aktiv'];
	$l_email=$data['email'];
	

	
	
			$sql= "UPDATE `lehrer` SET `wins` = '$wins', `email` = '$l_email', `level` = '$l_level', `lpw` = '$l_pw', `aktiv` = '$l_aktiv' WHERE `lehrer`.`lehrer_id` = '$lehrer_id'";

			if($db->query($sql))
			{
			return true;
			}
			else
			{
			return false;
			}
	}
function Klasse_vorhanden($data)
	{	
		global $db;	
	$klasse=$data['klasse'];
	
		$sql="SELECT klasse FROM klasse WHERE klasse='$klasse' ";
		
			($db_ergebnis=$db->query($sql));
			if (isset ($db_ergebnis[0] ))
			{ 
			return false;
			}
			else
			{	
			return true;
			}
	
	
	}
	
	
	

	function Klasse_vorhanden_mit_id($data) // aktuell nicht in Benutzung
	{	
		global $db;	
	$klasse=$data['klasse'];
	$klasse_id=$data['id'];

	
			$sql= "SELECT klasse FROM klasse WHERE (klasse='$klasse' AND klasse_id=$klasse_id)";
		
			($db_ergebnis=$db->query($sql));
			if (isset ($db_ergebnis[0] ))
			{ 
			return false;
			}
			else
			{	
			return true;
			}
	
	
	}
	
function klasse_updaten_db($data)
	{   
		global $db; //Wir verwenden die Standard-DB
	
		
		$klasse_id=$data['id'];
		$klasse= $data['klasse'];
		$sollstunden= $data['sollstunden'];

		$k_aktiv= $data['k_aktiv'];

	

			$sql= "UPDATE `klasse` SET `klasse` = '$klasse',  `sollstunden` = '$sollstunden', `aktiv` = '$k_aktiv' WHERE `klasse`.`klasse_id` = '$klasse_id'";
		
			if($db->query($sql))
			
			{
			
			return true;
			}
			else
			{
			return false;
			}
	}

function klasse_eintragen_db($data)
	{   
		global $db; //Wir verwenden die Standard-DB
	
		$klasse=$data['klasse'];
		$k_aktiv=$data['k_aktiv'];
		$sollstd=$data['sollstunden'];
	
	
	
		$sql = 'insert into klasse (klasse_id,klasse,aktiv,sollstunden) values (NULL,"'.$klasse.'","'.$k_aktiv.'","'.$sollstd.'")';
	      
			if($db->query($sql))
			{
			return true;
			}
			else
			{
			return false ;
			}
	}
	
function password_kontrolle ($data)
	
 { 
		global $db; //Wir verwenden die Standard-DB
		
		$l_pw = $data['l_pw'];
		$l_level =$data['l_level'];
 
		if ($l_pw  == "" && $l_level == "1")
		{
		echo "Admin muss ein Password haben!"; 
		}
		else 
		{
			if($l_pw != "" && $l_level == "0")	
			{
			echo "Lehrer darf kein Password haben!";
			}
			else 
			{
			return true;
			}
		}
}

function email_vergleich ($data)
{	
		global $db;	
		$email=$data['email'];
	
		$sql="SELECT * FROM lehrer WHERE email='$email' ";
		
			($db_ergebnis=$db->query($sql));
			if (isset ($db_ergebnis[0] ))
			{ 
			return false;
			}
			else
			{	
			return true;
			}
}

function verwaltung_lehrkraefte($data)
	{	
		global $db;	
		$sql = "SELECT wins,aktiv FROM `lehrer`";
	
		$db_verwaltung_lehrkräfte=$db->query($sql);
		return ($db_verwaltung_lehrkräfte);
		
	}
	
	?>
	

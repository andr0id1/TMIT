<?php	




function abweichungen($monat_id, $lehrer, $wohin)
{
	if (isset($_POST['save'.$lehrer.'']))
	{

		if($_POST['saveMonat']==$monat_id)
		{
		$formaction = "save";
		echo_r($_POST);
		$alles=$_POST;
		}
		else
		{
			$formaction="";
		}
	
	}
	else
	{
		$formaction="";
	}


	switch ($formaction)  // Je nach gespeichertem Befehl aus Formular eine Aktion ausführen
	{   
		case 'save':
		global $db;
		$datetime = date("Y-m-d H:i:s");
		$alleklassen=$alles['klassen'];


		if(isset($alles['insert'])) 		//Klassen die einen Insert haben sollen, diese werden eingetragen und von der Liste aller zu bearbeitenen Klassen genommen.
		{
			foreach($alles['insert'] AS $key=>$insertklasse)
			{
				$alleklassen=array_diff($alleklassen, array($insertklasse));
				$neuinsert=$alles[$insertklasse];
				$v=$neuinsert[1];
				$z=$neuinsert[2];
				$e=$neuinsert[3];
				$a=$neuinsert[4];

				if(($v !=="") || ($z !=="") || ($e !=="") || ($a !==""))
				{
                    $error=0;
                    if($v=="")
                    {
                        $v="NULL";
                    }
                    elseif (! is_numeric($v))
                    {
                        $error++;
                    }

                    if($z=="")
                    {
                        $z="NULL";
                    }
                    elseif (! is_numeric($z))
                    {
                        $error++;
                    }

                    if($e=="")
                    {
                        $e="NULL";
                    }
                    elseif (! is_numeric($e))
                    {
                        $error++;
                    }

                    if($a=="")
                    {
                        $a="NULL";
                    }
                    elseif (! is_numeric($a))
                    {
                        $error++;
                    }

                    if (empty($error))
                    {
                        $sql = 'insert into abweich (klasse_id,monat_id,v_h,z_h,e_h,a_h,eing_lehrer_id,eing_dat) values ((select klasse_id from klasse where klasse = "'.$insertklasse.'"),"'.$monat_id.'",'.$v.','.$z.','.$e.','.$a.',(SELECT lehrer.lehrer_id FROM lehrer WHERE lehrer.wins="'.$lehrer.'"),"'. $datetime.'")';
                        $result=$db->query($sql);
                        if($result==false)
                        {
                            echo("Es konnte kein neuer Eintrag erstellt werden.");
                            break;
                        }
                    }
                    else
                    {
                        echo ("Tragen Sie bitte nur Zahlen ein insert");
                    }
				}				
			}			
		}
	
		foreach($alleklassen AS $key=>$updateklasse)		//Alle klassen die in alleklassen vorhanden sind bekommen ein Update in der Datenbank.
		{
			global $db;
			$neuupdate=$alles[$updateklasse];
			$v=$neuupdate[1];
			$z=$neuupdate[2];
			$e=$neuupdate[3];
			$a=$neuupdate[4];

            if(($v =="") && ($z =="") && ($e =="") && ($a ==""))
            {
                $sql = 'DELETE FROM abweich WHERE abweich.klasse_id=(SELECT klasse.klasse_id FROM klasse WHERE klasse ="'.$updateklasse.'") AND abweich.monat_id = '.$monat_id.' ';
                $result=$db->query($sql);
                if($result==false)
                {
                    echo("Der Eintrag konnte nicht gelöscht werden.");
                    break;
                }
            }
            else
            {
                $error=0;
                if($v=="")
                {
                    $v="NULL";
                }
                elseif (! is_numeric($v))
                {
                    $error++;
                }

                if($z=="")
                {
                    $z="NULL";
                }
                elseif (! is_numeric($z))
                {
                    $error++;
                }

                if($e=="")
                {
                    $e="NULL";
                }
                elseif (! is_numeric($e))
                {
                    $error++;
                }

                if($a=="")
                {
                    $a="NULL";
                }
                elseif (! is_numeric($a))
                {
                    $error++;
                }

                if (empty($error))
                {
                    $sql = 'update abweich set v_h = '.$v.', z_h = '.$z.', e_h = '.$e.', a_h = '.$a .',eing_lehrer_id = (SELECT lehrer.lehrer_id FROM lehrer WHERE lehrer.wins="'.$lehrer.'"), eing_dat = "'.$datetime.'" where monat_id = "'.$monat_id.'" and klasse_id = (select klasse_id from klasse where klasse = "'.$updateklasse.'")';
                    $result=$db->query($sql);
                    if($result==false)
                    {
                        echo("Der Eintrag konnte nicht aktualisiert werden.");
                        break;
                    }
                }
                else
                {
                    echo ("Tragen Sie bitte nur Zahlen ein");
                }

            }

		}
		break;							
	}	


	global $db;
	$sql="SELECT klasse.klasse FROM klasse JOIN lehrer ON lehrer.lehrer_id=klasse.lehrer_id WHERE lehrer.wins='$lehrer'";
	$result=$db->query($sql);

	if($result==false)
    {
        echo "<h3>Es wurde keine Klasse zugewiesen</h3>";
    }
    else
    {


        echo "<form name='form1' action='$wohin' method='post'  enctype='multipart/form-data'>

	
	    <html>
        <table class='table table-responsive table-hover table-condensed'  summary='Abweichstunden'>
        <thead>
                <tr>
                <th>Klassen</th>
                <th>V</th>
                <th>Z</th>
                <th>E</th>
                <th>A</th>
            </tr>
        </thead>
        </html>
        ";

        $zählwertKlasse = 0;
        foreach ($result AS $key => $klassenName) {
            $klasse = $klassenName['klasse'];
            $arrayName1 = "$klasse" . "[" . "0" . "]";
            $arrayName2 = "klassen" . "[" . "$zählwertKlasse" . "]";
            echo("<input type = 'hidden' name='$arrayName1' value='$klasse'>");
            echo("<input type = 'hidden' name='$arrayName2' value='$klasse'>");

            global $db;
            $sql = "SELECT abweich.v_h, abweich.z_h, abweich.e_h, abweich.a_h FROM klasse
            JOIN abweich
            on abweich.klasse_id=klasse.klasse_id
            WHERE klasse.klasse='$klasse'
            and abweich.monat_id='$monat_id'
            ";
            $abweichungen = $db->query($sql);


            if (!isset($abweichungen[0])) {
                $arrayName3 = "insert" . "[" . "$zählwertKlasse" . "]";
                echo("<input type = 'hidden' name='$arrayName3' value='$klasse'>");
                $abweichungen = array(array("v_h" => "", "z_h" => "", "e_h" => "", "a_h" => ""));
            }

            echo("<tr>");
            echo("<td>$klasse</td>");
            $i = 1;
            foreach ($abweichungen[0] AS $NR => $abweichungenWerte) {
                $arrayName4 = "$zählwertKlasse" . "_" . "$i";
                $arrayName5 = "$klasse" . "[" . "$i" . "]";
                echo("<td valign='middle'' align='center'><input type='text1' class='form-control' value='$abweichungenWerte' name='$arrayName5' id='$arrayName4' onchange='Function$arrayName4()' maxlength='2' size='2'></td>
			<script>
			function Function$arrayName4() {
			document.getElementById('$arrayName4').className = 'updated';
			}
			</script>");
                $i++;
            }

            echo("</tr>");
            $zählwertKlasse++;
        }


        echo("</table>
	<style>
	.updated 
	{
		color: #04B404;
		font-weight:900
	}
	</style>");

        echo "<input type = 'hidden' name='saveMonat' value= '$monat_id' />";


        echo'
            <input type="submit" value="Speichern" class="btn btn-primary"><br>
            <input type="hidden" name="save'.$lehrer.'" value=1>

        </form>


        ';

    }
}




function zuweisen($lehrer, $wohin)
{

	if (isset($_POST['formaction']))
	{
		$formaction = $_POST["formaction"];
	}
	else
	{
		$formaction="";
	}	
			
	switch ($formaction)  // Je nach gespeichertem Befehl aus Formular eine Aktion ausführen
	{   // Löschbefehl erteilt
		case 'save':
		$alles=$_POST;
		
		$austragenKlassen=array_diff($alles['klassenIst'], $alles['klassenSoll']);

		if(empty($austragenKlassen)==false)
		{
			foreach($austragenKlassen AS $key=>$austragen)
			{
				$sql="UPDATE `klasse` SET `lehrer_id` = '0' WHERE `klasse`.`klasse` = '$austragen'";
				$ausgetragen=$db->query($sql);
				if($ausgetragen=true)
				{
					echo("Die Klasse $austragen wurde erfolgreich ausgetragen.<br>");
				}
				else
				{
					echo("Die Klasse $austragen konnte nicht ausgetragen werden.<br>");
				}
			}

		}


		if(isset ($alles['klassenDazu']))
		{
			$umtragenKlasse=$alles['klassenDazu'];
			foreach($umtragenKlasse AS $key=>$umtragen)
			{
				global $db;
				$sql="UPDATE `klasse` SET `lehrer_id` = (SELECT lehrer.lehrer_id FROM lehrer WHERE lehrer.wins='$lehrer') WHERE `klasse`.`klasse` = '$umtragen'";
				$umgetragen=$db->query($sql);
				if($umgetragen=true)
				{
					echo("Die Klasse $umtragen wurde erfolgreich umgetragen.<br>");
				}
				else
				{
					echo("Die Klasse $umtragen konnte nicht umgetragen werden.<br>");
				}
			}
		}	
	}			

	global $db;
	$sql="SELECT klasse.klasse FROM klasse WHERE klasse.aktiv= 1 AND klasse.lehrer_id=(select lehrer.lehrer_id from lehrer WHERE lehrer.wins='$lehrer' ) ORDER BY `klasse` ASC";
	$zugewieseneKlassen=$db->query($sql);
	$sql="SELECT klasse.klasse FROM klasse WHERE klasse.aktiv= 1 and klasse.lehrer_id =0 ORDER BY `klasse` ASC";
	$unzugewieseneKlassen=$db->query($sql);
	$sql="SELECT klasse.klasse FROM klasse WHERE klasse.aktiv= 1 and klasse.lehrer_id NOT IN (0) ORDER BY `klasse` ASC";
	$alleKlassen=$db->query($sql);
	
	

	echo "<form  action='$wohin' method='post' enctype='multipart/form-data'>";
	echo "<p></p><table border='1'>";
	echo "<tr>
		<th>Klassen</th>
		</tr>";
	$zählwertDurchläufe=0;
	foreach($zugewieseneKlassen AS $key=>$klassenName)
	{
		echo "<tr>";
		$value=$klassenName['klasse'];
		$arrayName6="klassenSoll"."["."$zählwertDurchläufe"."]";
		$arrayName7="klassenIst"."["."$zählwertDurchläufe"."]";
		echo("<td valign='middle' align='center'>$value</td>
		<td> <input type='checkbox' name='$arrayName6' value='$value' checked='checked'></td>");
		echo "</tr>";
		$zählwertDurchläufe++;
		echo("<input type = 'hidden' name='$arrayName7' value='$value'>");
	}

	echo "</table>";



	echo "<p></p><table border='1'>";
	echo "<tr>
		<th>Ohne Zuweisung</th>
		</tr>";

	$zählwertDurchläufe2=0;
	foreach($unzugewieseneKlassen AS $key=>$klassenName)
	{
		$arrayName8="klassenDazu"."["."$zählwertDurchläufe2"."]";
		echo "<tr>";
		$value=$klassenName['klasse'];
		echo("<td valign='middle' align='center'>$value</td>
		<td> <input type='checkbox' name='$arrayName8' value='$value'></td>");
		echo "</tr>";
		$zählwertDurchläufe2++;
	}

	echo "<tr>
		<td height=30></td>
		</tr>";
	echo "<tr>
		<th>Bereits zugewiesen</th>
		</tr>";
	
	foreach($alleKlassen AS $key=>$klassenName)
	{
		$arrayName9="klassenDazu"."["."$zählwertDurchläufe2"."]";
		echo "<tr>";
		$value=$klassenName['klasse'];
		echo("<td valign='middle' align='center'>$value</td>
		<td> <input type='checkbox' name='$arrayName9' value='$value'></td>");
		echo "</tr>";
		$zählwertDurchläufe2++;
	}

	?>

	</table>

	<input type="submit"value="Speichern"><br>
	<input type = "hidden" name="formaction" value="save" />
	</form>

	<?php
}



function monat($wohin)
{
	$date =  date("Y-m-d",time());
	$dateArray2 = explode('-',$date);
  
  	if ($dateArray2[1] > 1)
	{
		$dateArray2[1] = $dateArray2[1] - 1;
	}     // muss aktiv werden, wenn Oktober eingetragen  
  	else 
  	{
     	$dateArray2[1] = '12';
	 	$dateArray2[0] = $dateArray2[0] - 1;
	}
  
  	$date2 = $dateArray2[0].'-'.$dateArray2[1].'-'.$dateArray2[2];

	global $db;
	$sql = 'select * from monat where "'.$date.'" between vondat and bisdat order by vondat';
	$result=$db->query($sql);
	$aktuellerMonat=$result[0];

	$sql = 'select * from monat where "'.$date2.'" between vondat and bisdat order by vondat';
	$result=$db->query($sql);
	$letzterMonat=$result[0];

	if(isset($_POST['monat_id']))
	{
		$monatNummer=$_POST['monat_id'];
		switch($monatNummer)
		{
			case $aktuellerMonat['monat_id']:
			$checked1= "checked='checked'";
			$checked2= "";
			break;

			case $letzterMonat['monat_id']:
			$checked1= "";
			$checked2= "checked='checked'";
			break;
		}
	}
	else
	{
		$monatNummer=$aktuellerMonat['monat_id'];
		$checked1= "checked='checked'";
		$checked2= "";
	}

	$vonDatumAktuell = date("d.m ", strToTime($aktuellerMonat['vondat']));
    $bisDatumAktuell = date("d.m ", strToTime($aktuellerMonat['bisdat']));
	$vonDatumAlt = date("d.m ", strToTime($letzterMonat['vondat']));
    $bisDatumAlt = date("d.m ", strToTime($letzterMonat['bisdat']));

	echo "<form name='form2'  action='$wohin' method='post' enctype='multipart/form-data'>";

	echo "<p></p><table border=0>";
	echo "<tr>
		<th></th>
		<th>Monat</th>
		<th>von - bis</th>
		</tr>";

	echo"<tr>
	<td><input type='radio' ",$checked2," onchange='document.form2.submit()' name='monat_id' value='",$letzterMonat['monat_id'],"'></td>
	<td WIDTH='70'>", $letzterMonat['monat'] ,"</td>
	<td>",$vonDatumAlt ," - ",$bisDatumAlt ,"</td>
	</tr>";

	echo"<tr>
	<td><input type='radio' ",$checked1," onchange='document.form2.submit()' name='monat_id' value='",$aktuellerMonat['monat_id'],"'></td>
	<td WIDTH='70'>", $aktuellerMonat['monat'] ,"</td>
	<td>",$vonDatumAktuell ," - ",$bisDatumAktuell ,"</td>
	</tr>";

	echo"</table><br><br><br>";

	echo"
	<noscript>
	<input type='submit' value='Übernehmen'><br>
	</noscript>
	</form>";

	return $monatNummer;
}

function httpPost($url, $data)
{
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}

function lehrerAnzeigen($lehrer_id, $wins)      //Die Lehrer ID oder den Lehrer Wins angeben und den anderen Wert auf 0 setzten.
{
    if(empty($wins))
    {
        global $db;
        $sql = 'SELECT wins FROM lehrer WHERE lehrer.lehrer_id = '.$lehrer_id.'';
        $result=$db->query($sql);
        $wins=$result[0]['wins'];
        echo "<table border='1'><tr><td>Gewählter Lehrer: <br><h3>$wins</h3></td></tr></td></table>";
    }
    elseif (empty($lehrer_id))
    {
        echo "<table border='1'><tr><td>Gewählter Lehrer: <br><h3>$wins</h3></td></tr></td></table>";
    }
}

function lehrerOffline()
{
    global $db;
    $sql = 'SELECT lehrer_id FROM klasse WHERE klasse.aktiv= 1 and klasse.lehrer_id NOT IN (0) ORDER BY klasse.lehrer_id ASC';
    $result=$db->query($sql);
    array_walk_recursive($result, function($value) use (&$klassenIDs)
    {
        $klassenIDs[] = $value;
    });

    $sql = 'SELECT lehrer_id FROM lehrer WHERE lehrer.aktiv=1 AND lehrer.level=0 ORDER BY lehrer_id ASC';
    $result=$db->query($sql);
    array_walk_recursive($result, function($value) use (&$lehrerIDs)
    {
        $lehrerIDs[] = $value;
    });

    $ohneKlasseID=array_diff($lehrerIDs,$klassenIDs);

    foreach($ohneKlasseID AS $key=>$ID)
    {
        $sql = 'UPDATE lehrer SET aktiv = 0 WHERE lehrer.lehrer_id = '.$ID.'';
        $result=$db->query($sql);
        if($result==false)
        {
            echo "Die Lehrer ID $ID konnte nicht inaktiv geschaltet werden";
        }
    }


}
?>

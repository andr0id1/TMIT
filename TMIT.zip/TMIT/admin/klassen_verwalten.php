<?php session_start();
/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 14.03.17
 * Time: 21:16
 */

require("../inc/includes.php");

if($_SESSION['nutzer_level']!=1)
{
    header('Location: ../www/index.php');
    exit;
}

if (isset($_POST['formaction']))
{
    $formaction = $_POST["formaction"];
}
else
{
    $daten = array();
    $formaction="";
}

if(!isset($_GET["seite"]) || !is_numeric($_GET["seite"])) 		// Hier wird die Anzahl eingetragener Lehrer ermittelt
{
    $_GET["seite"] = 1;
}

if(ISSET($_POST['k_aktiv']))    							   // Anzeigen: nicht aktiv-,aktiv-, Alle Klassen
{
    $_SESSION['k_aktiv']=$_POST['k_aktiv'];
    $klassen_filter =$_SESSION['k_aktiv'];
}
else
{
    if(ISSET($_SESSION['k_aktiv']))
    {
        $klassen_filter =$_SESSION['k_aktiv'];
    }
    else
    {
        $klassen_filter =2;
        $_SESSION['k_aktiv']=2;
    }
}

global $db;
switch($klassen_filter)
{
    case 0:
        $sql=("SELECT COUNT(*) as anzahl FROM klasse WHERE aktiv=0");
        break;
    case 1:
        $sql=("SELECT COUNT(*) as anzahl FROM klasse WHERE aktiv=1");
        break;
    case 2:
        $sql=("SELECT COUNT(*) as anzahl FROM klasse");
        break;
}
$anzahl = $db->query($sql);

if(ISSET($_POST['pro_seite']))    							   // Einstellen wie viele Einträge pro Seite
{
    $_SESSION['angezeigt']=$_POST['pro_seite'];
    $eintraege_pro_seite =$_SESSION['angezeigt'];
}
else
{
    if(ISSET($_SESSION['angezeigt']))
    {
        $eintraege_pro_seite =$_SESSION['angezeigt'];
    }
    else
    {
        $eintraege_pro_seite =25;
        $_SESSION['angezeigt']=25;
    }
}


if ($anzahl[0]['anzahl'] % $eintraege_pro_seite == 0)
{
    $hoechst = $anzahl / $eintraege_pro_seite;
}
else
{
    $hoechst = $anzahl[0]['anzahl'] / $eintraege_pro_seite + 1;
}

if ($_GET["seite"] > $hoechst || $_GET["seite"] < 1)
{
    $_GET["seite"] = 1;
}

$start = $_GET["seite"] * $eintraege_pro_seite - $eintraege_pro_seite;

switch($klassen_filter)
{
    case 0:
        $sql = "SELECT * 
									FROM klasse 
									WHERE aktiv =0
									ORDER BY `klasse`.`klasse` ASC LIMIT $start, $eintraege_pro_seite ";			//Sql abfrage für die Tabelle (nicht aktive klassen)
        break;
    case 1:
        $sql = "SELECT * 
									FROM klasse 
									WHERE aktiv =1
									ORDER BY `klasse`.`klasse` ASC LIMIT $start, $eintraege_pro_seite ";			//Sql abfrage für die Tabelle (alle aktive klassen)
        break;
    case 2:
        $sql = "SELECT * 
									FROM klasse 
									ORDER BY `klasse`.`klasse` ASC LIMIT $start, $eintraege_pro_seite ";			//Sql abfrage für die Tabelle (alle klassen)
        break;
}

$alle_klassen = $db->query($sql);


$ausgabe = "";

for($i=1; $i <= $hoechst; $i++)     // Hier wird die aktuelle Seite ohne link geschrieben und die anderen Seiten werden verlinkt
{
    if ($_GET["seite"] == $i )
    {
        $ausgabe .= " <a class='btn btn-primary sharp btn-xs active'>$i</a> ";
    }
    else
    {
        $ausgabe .= " <a class='btn btn-primary sharp btn-xs' href='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "?seite=$i'>$i</a> ";
    }
}

?>
<!DOCTYPE html>
<html lang="de">
<head>
    <title>Verwaltung</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar-fixed-side.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
    <link href="../css/buttons.css" rel="stylesheet" />
    <link href="../css/tables.css" rel="stylesheet" />
</head>
<body>


<div class="container-fluid mantel">
    <div class="row">
        <div class="col-sm-4 col-md-3 col-lg-2">
            <nav class="navbar navbar-custom navbar-fixed-side">
                <div class="container">
                    <div class="navbar-header">
                        <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="../www/index.php" title="Zum Index">
                            <img src="../bilder/logo_RBZ.png" style="width: 80px; height: 63px;">
                            <h3>
                                Verwaltung
                            </h3>
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="">
                        <ul class="nav navbar-nav">
                            <li class="">
                                <a href="admindex.php"><span class="glyphicon glyphicon-calendar"></span> Abweichung</a>
                            </li>
                            <li class="">
                                <a href="lehrer_verwalten.php"><span class="glyphicon glyphicon-user"></span> Lehrer verwalten</a>
                            </li>
                            <li class="active">
                                <a href="klassen_verwalten.php"><span class="glyphicon glyphicon-education"></span> Klassen verwalten</a>
                            </li>
                            <li class="">
                                <a href="uebersicht.php"><span class="glyphicon glyphicon-list"></span> Übersicht</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <div class="col-sm-8 col-lg-10">
            <div class="row">

                <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                    <h1>
                        Administration
                        <br>
                        <small>
                            Klassen verwalten
                        </small>
                    </h1>

                </div>
                <div class="col-lg-2 col-md-3 col-lg-offset-1 btn-abs col-sm-4 col-xs-12">
                    <a class="btn btn-primary btn-sm sharp btn-block top-buffer" href="../www/logout.php">Logout</a>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-lg-4 col-sm-10">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form action="lehrer_verwalten.php" name="pro_seite" method="post">
                                        <label style="width: 14rem;" for="anzahl">Einträge pro Seite: </label>
                                        <select id="anzahl" class="" onchange="document.pro_seite.submit()" size="1" name="pro_seite" >
                                            <option <?PHP if($_SESSION['angezeigt']==25) echo 'selected="selected"'; ?>  >25</option>
                                            <option <?PHP if($_SESSION['angezeigt']==50) echo 'selected="selected"'; ?>  >50</option>
                                            <option <?PHP if($_SESSION['angezeigt']==75) echo 'selected="selected"'; ?>  >75</option>
                                            <option <?PHP if($_SESSION['angezeigt']==100) echo 'selected="selected"'; ?> >100</option>
                                            <option <?PHP if($_SESSION['angezeigt']==200) echo 'selected="selected"'; ?> >200</option>
                                        </select>
                                        <noscript>
                                            <input class="btn btn-primary btn-sm sharp" type="submit" value="Übernehmen"><br>
                                        </noscript>
                                    </form>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <form action="klassen_verwalten.php" name="k_aktiv" method="post">
                                        <label style="width: 14rem;" for="aktiv">Status:</label>
                                        <select id="aktiv" onchange="document.k_aktiv.submit()" size="1" name="k_aktiv" >
                                            <option <?PHP if($_SESSION['k_aktiv']==2) echo 'selected="selected"';?> value="2"  >alle</option>
                                            <option <?PHP if($_SESSION['k_aktiv']==1) echo 'selected="selected"';?>  value="1" >aktiv</option>
                                            <option <?PHP if($_SESSION['k_aktiv']==0) echo 'selected="selected"'; ?>  value="0" >inativ</option>
                                        </select>
                                        <noscript>
                                            <input class="btn btn-primary btn-sm sharp" type="submit" value="Übernehmen"><br>
                                        </noscript>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <label >Seite: </label>
                            <?php echo $ausgabe; ?>
                        </div>
                    </div>
                    <div class="row top-buffer">
                        <div class="col-lg-12">
                            <table class="table table-responsive minimalist-b">
                                <tr>
                                    <th>Klasse</th>
                                    <th>Aktiv</th>
                                    <th></th>
                                    <th></th>
                                </tr>

                                <?php
                                foreach ($alle_klassen AS $id=>$a)
                                {
                                    $klasse="$a[klasse]";
                                    $aktiv="$a[aktiv]";         //todo-bo guten ersatz für aktiv und adminstatus finden, symbole order farben die zum designe passen.
                                    $klasse_id="$a[klasse_id]";
									$Status ="";
									if ($aktiv == 1)					//Aktiv inaktiv Ausgabe auf Symbol geändert
										{
											$Status .="<span class='glyphicon glyphicon-ok' aria-hidden='true'></span>";
										}
										else
										{
											$Status .="<span class='glyphicon glyphicon-remove' aria-hidden='true'></span>";
										}
                                    echo'
                                    <form>
                                    <tr>
                                        <td><h4>'.$klasse.'</h4></td>
                                        <td>'.$Status.'</td>
        
                                        <td width="30%">
                                            <input type = "hidden" name="data[id]" value="'.$klasse_id.'" >
                                            <input type="submit" class="btn btn-primary btn-sm sharp"  formaction= klassen_bearbeiten.php formmethod="get"  value="Klasse Bearbeiten">
                                        </td>
                                        <td>
                                            <input type="submit" class="btn btn-primary btn-sm sharp"  formaction= klassen_lehrerZuweisen.php formmethod="get" value="Lehrer zuweisen">
                                        </td>
                                    </tr>
                                    </form>';
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-4">
                            <label >Seite: </label>
                            <?php echo $ausgabe; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <form>
                        <input type="submit" class="btn btn-primary btn-sm sharp btn-block"  formaction= "klassen_anlegen.php" formmethod="post"  value="Neue Klasse anlegen">
                    </form>
                </div>
            </div>
            <div class="row top-buffer-groß">
                <br>
            </div>
        </div>
    </div>
</div>


<footer class="footer">
    <div class="container-fluid">
            <?php
            $datum = date("d.m.Y H:i");
            echo"$datum";
            ?>

    </div>
</footer>

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</body>
</html>


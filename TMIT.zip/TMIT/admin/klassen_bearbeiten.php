<?php session_start();
/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 14.03.17
 * Time: 21:16
 */

require("../inc/includes.php");

if($_SESSION['nutzer_level']!=1)
{
    header('Location: ../www/index.php');
    exit;
}


$nachricht="";
$error="";

if(isset($_POST['data']))
{
    $data=$_POST['data'];

    if ($data['klasse'] !="")  // wurde ein Lehrerkürzel eingegeben?
    {
        if(klasse_updaten_db($data))
        {
            $nachricht.="Die Änderungen wurden übernommen<br>";
        }
        else
        {
            $error.="Die Änderung ist fehlgeschlagen<br>";
        }
    }
    else
    {
        $error.="Das Lehrkraft-Eingabefeld war leer!<br>";
    }
}

if(isset($_GET))
{
    $auswahl=$_GET['data']['id'];
    if (isset($auswahl)) 			// Daten von Verwaltung_Lehrkraefte.php
    {
        global $db;
        $sql="SELECT * FROM klasse WHERE klasse_id='$auswahl'";
        $db_klasse_bearbeiten=$db->query($sql);

        $klasse=$db_klasse_bearbeiten[0]['klasse'];
        $sollstd=$db_klasse_bearbeiten[0]['sollstunden'];
        $aktiv=$db_klasse_bearbeiten[0]['aktiv'];
        $klasse_id=$db_klasse_bearbeiten[0]['klasse_id'];

        if($aktiv==0)
        {
            global $db;
            $sql="SELECT lehrer_id FROM klasse WHERE klasse.klasse_id='$klasse_id'";
            $result=$db->query($sql);
            $lehrer_id=$result[0]['lehrer_id'];
            $sql="UPDATE klasse SET klasse.lehrer_id=0 WHERE klasse.klasse_id='$klasse_id'";
            $result=$db->query($sql);
            lehrerOnOff($lehrer_id);
            if($result==false)
            {
                $error.="Die zugehörige Klasse konnte nicht ausgetragen werden.";
            }
        }
    }
}
else
{
    header('Location: lehrer_verwalten.php');
}



?>
<!DOCTYPE html>
<html lang="de">
<head>
    <title>Verwaltung</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar-fixed-side.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
    <link href="../css/buttons.css" rel="stylesheet" />
    <link href="../css/tables.css" rel="stylesheet" />
</head>
<body>


<div class="container-fluid mantel">
    <div class="row">
        <div class="col-sm-4 col-md-3 col-lg-2">
            <nav class="navbar navbar-custom navbar-fixed-side">
                <div class="container">
                    <div class="navbar-header">
                        <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="../www/index.php" title="Zum Index">
                            <img src="../bilder/logo_RBZ.png" style="width: 80px; height: 63px;">
                            <h3>
                                Verwaltung
                            </h3>
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="">
                        <ul class="nav navbar-nav">
                            <li class="">
                                <a href="admindex.php"><span class="glyphicon glyphicon-calendar"></span> Abweichung</a>
                            </li>
                            <li class="">
                                <a href="lehrer_verwalten.php"><span class="glyphicon glyphicon-user"></span> Lehrer verwalten</a>
                            </li>
                            <li class="active">
                                <a href="klassen_verwalten.php"><span class="glyphicon glyphicon-education"></span> Klassen verwalten</a>
                            </li>
                            <li class="">
                                <a href="uebersicht.php"><span class="glyphicon glyphicon-list"></span> Übersicht</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <div class="col-sm-8 col-lg-10">
            <div class="row">

                <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                    <h1>
                        Administration
                        <br>
                        <small>
                            Klassen bearbeiten
                        </small>
                    </h1>

                </div>
                <div class="col-lg-2 col-md-3 col-lg-offset-1 btn-abs col-sm-4 col-xs-12">
                    <a class="btn btn-primary btn-sm sharp btn-block top-buffer" href="../www/logout.php">Logout</a>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-lg-3 col-lg-offset-1">
                    <h2>Klasse bearbeiten</h2>
                    <br>
                    <form action="klassen_bearbeiten.php<?php echo'?data%5Bid%5D='.$auswahl.''?>" method="post">

                        <label for="wins">Klasse:</label>
                        <input id="wins" style="display: block" type="text" name="data[klasse]" value= <?PHP echo"$klasse"?>><br>
                        <input type="hidden" name="data[id]" value="<?php echo $auswahl ?>">

                        <br>

                        <fieldset>
                            <legend>Aktivitäts-Status</legend>
                            <label class="breite" for="active">aktiv</label>
                            <input id="active" type = "radio" name = "data[k_aktiv]" value = "1" <?PHP if($aktiv ==1) echo 'checked="checked"';?>><br>
                            <label class="breite" for="inactive">nicht aktiv</label>
                            <input id="inactive" type = "radio" name = "data[k_aktiv]" value = "0" <?PHP if($aktiv ==0) echo 'checked="checked"';?>><br>
                        </fieldset>
                        <br>

                        <label for="sollstunden">Sollstunden:</label>
                        <input id="sollstunden" style="display: block" type="text" name="data[sollstunden]" value= <?PHP echo"$sollstd"?>><br>

                        <input class="btn btn-primary btn-sm sharp" type="submit" value="Änderung sichern">
                    </form>
                </div>
                <div class="col-lg-5 col-lg-offset-1">
                    <h4 style="color: red">
                        <?php echo $error; ?>
                    </h4>
                    <h4>
                    <?php echo $nachricht; ?>
                    </h4>
                </div>
            </div>
            <div class="row top-buffer-groß">
                <br>
            </div>
        </div>
    </div>
</div>


<footer class="footer">
    <div class="container-fluid">
            <?php
            $datum = date("d.m.Y H:i");
            echo"$datum";
            ?>

    </div>
</footer>

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</body>
</html>


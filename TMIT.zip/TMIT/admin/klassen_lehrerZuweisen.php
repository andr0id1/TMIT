<?php session_start();
/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 14.03.17
 * Time: 21:16
 */

require("../inc/includes.php");

if($_SESSION['nutzer_level']!=1)
{
    header('Location: ../www/index.php');
    exit;
}


?>
<!DOCTYPE html>
<html lang="de">
<head>
    <title>Verwaltung</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar-fixed-side.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
    <link href="../css/buttons.css" rel="stylesheet" />
    <link href="../css/tables.css" rel="stylesheet" />
</head>
<body>


<div class="container-fluid mantel">
    <div class="row">
        <div class="col-sm-4 col-md-3 col-lg-2">
            <nav class="navbar navbar-custom navbar-fixed-side">
                <div class="container">
                    <div class="navbar-header">
                        <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="../www/index.php" title="Zum Index">
                            <img src="../bilder/logo_RBZ.png" style="width: 80px; height: 63px;">
                            <h3>
                                Verwaltung
                            </h3>
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="">
                        <ul class="nav navbar-nav">
                            <li class="">
                                <a href="admindex.php"><span class="glyphicon glyphicon-calendar"></span> Abweichung</a>
                            </li>
                            <li class="">
                                <a href="lehrer_verwalten.php"><span class="glyphicon glyphicon-user"></span> Lehrer verwalten</a>
                            </li>
                            <li class="active">
                                <a href="klassen_verwalten.php"><span class="glyphicon glyphicon-education"></span> Klassen verwalten</a>
                            </li>
                            <li class="">
                                <a href="uebersicht.php"><span class="glyphicon glyphicon-list"></span> Übersicht</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <div class="col-sm-8 col-lg-10">
            <div class="row">

                <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                    <h1>
                        Administration
                        <br>
                        <small>
                            Lehrer zuweisen
                        </small>
                    </h1>

                </div>
                <div class="col-lg-2 col-md-3 col-lg-offset-1 btn-abs col-sm-4 col-xs-12">
                    <a class="btn btn-primary btn-sm sharp btn-block top-buffer" href="../www/logout.php">Logout</a>
                </div>
            </div>
            <hr>
            <div class="row">
                <?php
                if((isset($_GET['data']['id'])))
                {
                    $klassenID=$_GET['data']['id'];
                    klasseLehrerZuweisen2($klassenID,"klassen_lehrerZuweisen.php");
                }
                else
                {
                    header('Location: klassen_verwalten.php');
                }
                ?>
            </div>
            <div class="row">
                <br>
            </div>
        </div>
    </div>
</div>


<footer class="footer">
    <div class="container-fluid">
            <?php
            $datum = date("d.m.Y H:i");
            echo"$datum";
            ?>

    </div>
</footer>

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</body>
</html>


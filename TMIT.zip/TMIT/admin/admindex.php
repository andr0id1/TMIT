<?php session_start();
/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 14.03.17
 * Time: 21:16
 */

require("../inc/includes.php");

if($_SESSION['nutzer_level']!=1)
{
    header("Location: ../www/index.php");
    exit;
}

$error="";

global $db;
$sql = 'SELECT DISTINCT lehrer.wins FROM lehrer INNER JOIN klasse ON klasse.lehrer_id=lehrer.lehrer_id ORDER BY `wins`  ASC';

$result=$db->query($sql);


if(isset($_POST['lehrerauswahl']))
{
    if(!empty($_POST['lehrerauswahl']))
    {
        if(searchForWins($_POST['lehrerauswahl'],$result))
        {
            $lehrerauswahl=$_POST['lehrerauswahl'];
        }
        else
        {
            $name=$_POST['lehrerauswahl'];
            $error.="Es ist kein Lehrer mit dem Namen $name bekannt";
        }
    }
    else
    {
        $error.="Bitte füllen sie das Feld vorher aus";
    }
}



$datalist= "<datalist id='lehrer'>";
foreach($result AS $key=>$lehrer)
{
    $lehrerJetzt=$lehrer['wins'];
    $datalist.="<option value='".$lehrerJetzt."'>";
}
$datalist.= "</datalist>";



?>
<!DOCTYPE html>
<html lang="de">
<head>
    <title>Verwaltung</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar-fixed-side.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
    <link href="../css/buttons.css" rel="stylesheet" />
    <link href="../css/tables.css" rel="stylesheet" />
</head>
<body>


<div class="container-fluid mantel">
    <div class="row">
        <div class="col-sm-4 col-md-3 col-lg-2">
            <nav class="navbar navbar-custom navbar-fixed-side">
                <div class="container">
                    <div class="navbar-header">
                        <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="../www/index.php" title="Zum Index">
                            <img src="../bilder/logo_RBZ.png" style="width: 80px; height: 63px;">
                            <h3>
                                Verwaltung
                            </h3>
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="">
                        <ul class="nav navbar-nav">
                            <li class="active">
                                <a href="admindex.php"><span class="glyphicon glyphicon-calendar"></span> Abweichung</a>
                            </li>
                            <li class="">
                                <a href="lehrer_verwalten.php"><span class="glyphicon glyphicon-user"></span> Lehrer verwalten</a>
                            </li>
                            <li class="">
                                <a href="klassen_verwalten.php"><span class="glyphicon glyphicon-education"></span> Klassen verwalten</a>
                            </li>
                            <li class="">
                                <a href="uebersicht.php"><span class="glyphicon glyphicon-list"></span> Übersicht</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <div class="col-sm-8 col-lg-10">
            <div class="row">

                <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                    <h1>
                        Administration
                        <br>
                        <small>
                            Abweichungen
                        </small>
                    </h1>

                </div>
                <div class="col-lg-2 col-md-3 col-lg-offset-1 btn-abs col-sm-4 col-xs-12">
                    <a class="btn btn-primary btn-sm sharp btn-block top-buffer" href="../www/logout.php">Logout</a>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-lg-3 col-md-4 col-sm-8 col-xs 10 col-xs-offset-1">
                    <?php $monat=monat("admindex.php");
                    echo $datalist;?>
                </div>
                <div class="col-lg-8 col-md-7 col-sm-10 col-xs-12 border-left">
                    <div class="row">
                        <div class="col-lg-12">
                            <table>
                                <tr>
                                    <td>
                                        <form action="admindex.php" method="post">
                                            <input size="12" type="text" name="lehrerauswahl" list="lehrer" placeholder="Lehrer wählen">
                                    </td>
                                    <td>
                                        <input type="submit" value="Wählen" class="btn btn-primary btn-sm sharp left-buffer">
                                        </form>
                                    </td>
                                    <td>
                                        <p>
                                        <form>
                                            <input type="submit" value="Reset" formaction="admindex.php" formmethod="post" class="btn btn-primary btn-sm sharp left-buffer">
                                        </form>
                                        </p>

                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <h4>Die Einträge sind erst nach dem Speichern gesichert!</h4>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <h4 style="color: red"><?php echo $error ?></h4>
                        </div>
                    </div>
                    <div class="row top-buffer">
                        <div class="col-lg-12">
                            <?php

                            if(isset($lehrerauswahl))
                            {
                                echo "<hr><div class='row'> <div class='col-lg-2'>
                                    <h2>$lehrerauswahl</h2>
                                    </div>
                                    <div class='col-lg-7'>";
                                abweichungen("$monat","$lehrerauswahl","admindex.php");
                                echo ("</div></div>");
                            }
                            else
                            {
                                foreach($result AS $key=>$lehrer)
                                {
                                    $lehrerJetzt=$lehrer['wins'];
                                    echo "<hr><div class='row'> <div class='col-lg-2'>
                                    <h2>$lehrerJetzt</h2>
                                    </div>
                                    <div class='col-lg-7'>";
                                    abweichungen("$monat","$lehrerJetzt","admindex.php");
                                    echo ("</div></div>");
                                }
                            }

                            ?>
                        </div>
                    </div>
                    <div class="row top-buffer">
                        <br>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<footer class="footer">
    <div class="container-fluid">

            <?php
            $datum = date("d.m.Y H:i");
            echo"$datum";
            ?>

    </div>
</footer>

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</body>
</html>


<?php session_start();
/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 14.03.17
 * Time: 21:16
 */

require("../inc/includes.php");

if($_SESSION['nutzer_level']!=1)
{
    header('Location: ../www/index.php');
    exit;
}

$nachricht="";
$error="";

if(isset($_POST['data']))
{
    $data= $_POST['data'];

    if ($data['klasse'] !="")  // wurde eine Klasse eingegeben?
    {

        if(Klasse_vorhanden($data)) //  is die Klasse schon vorhanden?
        {

            if(klasse_eintragen_db($data)) // Klasse eintragen
            {
                $klasse=$data['klasse'];
                $sql="SELECT * FROM klasse WHERE klasse='$klasse'";
                $db_klasse_eintragen=$db->query($sql);

                if($db_klasse_eintragen[0]['aktiv']==1)
                {
                    $aktivStatus="aktiv";
                }
                else
                {
                    $aktivStatus="inaktiv";
                }

                $nachricht='
                        <h4> Die Klasse wurde erfolgreich angelegt.<br> 
                        Hinzugefügt wurde:<br></h4>
                        
                        <table class="minimalist-b">
                        <tr>
                            <td><b>Klasse:</b></td>
                            <td>'.$db_klasse_eintragen[0]['klasse'].'</td>
                        </tr>
                        <tr>
                            <td><b>Sollsunden:</b></td>
                            <td>'.$db_klasse_eintragen[0]['sollstunden'].'</td>
                        </tr>
                        <tr>
                            <td><b>Aktivitäts-Status:</b></td>
                            <td>'.$aktivStatus.'</td>
                        </tr>
                        <tr>
                            <td>
                                <a class="btn btn-primary btn-sm sharp" href="klassen_lehrerZuweisen.php?data%5Bid%5D='.$db_klasse_eintragen[0]['klasse_id'].'">Lehrer zuweisen</a>
                            </td>
                            <td>
                            
                            </td>
                        </tr>
                        </table>';
            }
            else
            {
                $error.="Klasse anlegen fehlgeschlagen";
            }
        }
        else
        {
            $error.="Dieses Kürzel ist schon vorhanden!";
        }
    }
    else
    {
        $error.="Das Klassen Eingabefeld war leer!";
    }
}


?>
<!DOCTYPE html>
<html lang="de">
<head>
    <title>Verwaltung</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar-fixed-side.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
    <link href="../css/buttons.css" rel="stylesheet" />
    <link href="../css/tables.css" rel="stylesheet" />
</head>
<body>


<div class="container-fluid mantel">
    <div class="row">
        <div class="col-sm-4 col-md-3 col-lg-2">
            <nav class="navbar navbar-custom navbar-fixed-side">
                <div class="container">
                    <div class="navbar-header">
                        <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="../www/index.php" title="Zum Index">
                            <img src="../bilder/logo_RBZ.png" style="width: 80px; height: 63px;">
                            <h3>
                                Verwaltung
                            </h3>
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="">
                        <ul class="nav navbar-nav">
                            <li class="">
                                <a href="admindex.php"><span class="glyphicon glyphicon-calendar"></span> Abweichung</a>
                            </li>
                            <li class="">
                                <a href="lehrer_verwalten.php"><span class="glyphicon glyphicon-user"></span> Lehrer verwalten</a>
                            </li>
                            <li class="active">
                                <a href="klassen_verwalten.php"><span class="glyphicon glyphicon-education"></span> Klassen verwalten</a>
                            </li>
                            <li class="">
                                <a href="uebersicht.php"><span class="glyphicon glyphicon-list"></span> Übersicht</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <div class="col-sm-8 col-lg-10">
            <div class="row">

                <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                    <h1>
                        Administration
                        <br>
                        <small>
                            Klassen anlegen
                        </small>
                    </h1>

                </div>
                <div class="col-lg-2 col-md-3 col-lg-offset-1 btn-abs col-sm-4 col-xs-12">
                    <a class="btn btn-primary btn-sm sharp btn-block top-buffer" href="../www/logout.php">Logout</a>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-lg-3 col-lg-offset-1">
                    <h2>Klasse hinzufügen</h2>
                    <br>
                    <form action="klassen_anlegen.php" method="post">

                        <label for="klasse">Klasse:</label>
                        <input id="klasse" style="display: block" type="text" name="data[klasse]"><br>
                        <br>

                        <fieldset>
                            <legend>Aktivitäts-Status</legend>
                            <label class="breite" for="active">aktiv</label>
                            <input id="active" type = "radio" name = "data[k_aktiv]" value = "1" checked><br>
                            <label class="breite" for="inactive">nicht aktiv</label>
                            <input id="inactive" type = "radio" name = "data[k_aktiv]" value = "0" ><br>
                        </fieldset>
                        <br>

                        <label for="sollstunden">Sollstunden:</label>
                        <input id="sollstunden" style="display: block" type="text" name="data[sollstunden]">
                        <br>

                        <input class="btn btn-primary btn-sm sharp" type="submit" value="Klasse anlegen">
                    </form>
                </div>
                <div class="col-lg-5 col-lg-offset-1">
                    <h4 style="color: red">
                        <?php echo $error; ?>
                    </h4>
                    <?php echo $nachricht; ?>
                </div>
            </div>
            <div class="row top-buffer-groß">
                <br>
            </div>
        </div>
    </div>
</div>


<footer class="footer">
    <div class="container-fluid">
            <?php
            $datum = date("d.m.Y H:i");
            echo"$datum";
            ?>

    </div>
</footer>

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</body>
</html>


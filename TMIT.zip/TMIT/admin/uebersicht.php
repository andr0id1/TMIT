<?php session_start();
/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 14.03.17
 * Time: 21:16
 */

require("../inc/includes.php");

if($_SESSION['nutzer_level']!=1)
{
    header('Location: ../www/index.php');
    exit;
}

global $db;


$sql = "SELECT * FROM `klasse` WHERE `lehrer_id`='' ORDER BY `klasse`.`klasse` ASC";
$klasse = $db->query($sql);

$sql="SELECT lehrer.wins, lehrer.lehrer_id FROM lehrer LEFT JOIN klasse ON (klasse.lehrer_id = lehrer.lehrer_id) WHERE klasse.lehrer_id IS NULL ORDER BY `wins`  ASC";
$unzugewieseneLehrer=$db->query($sql);

if (isset($_POST['formaction']))
{
    $formaction = $_POST["formaction"];
}
else
{
    $formaction="";
}

switch ($formaction)
{ 
    case'email':
	
	$monat=$_SESSION['monat_id'];
    $empfaenger= $_POST['empfaenger'];
    $sql="SELECT monat FROM monat WHERE monat_id=$monat";
	$mo=$db->query($sql);
	$zeitraum=$mo[0][monat];
    $wins= $_POST['wins'];
    $link = 'http://testdev.eckener-schule.de/TMIT/lehrer/www/index.php';
    $betreff="Stundenabweichungen";
    $text= "Hallo $wins, hiermit erinnere ich Sie daran die Stundenabweichungen für Ihre Klassen im Abrechnungszeitraum $zeitraum nachzutragen. . \r\n";
    $text .="Hier ist ihr Link zum login $link ";
    $nachricht= str_replace("\n.","\n..",$text);
    $headers  = 'From: TIMT <testdev@eckener-schule.de>';
    $headers .= "Mime-Version: 1.0\r\n";
    $headers .= "Content-type: text/plain; charset=utf-8";

    if(mail($empfaenger, $betreff, $nachricht, $headers)==true)
    {
	
        ?>
        <script>
            alert("Die E-Mail wurde erfolgreich versendet :)");
        </script>
        <?php       //todo-me nachricht ausgabe ändern
    }
    else
    {
        ?>
        <script>
            alert("Die E-Mail konnte leider nicht versendet werden.. \r\n Bitte kontrolliere die Auswahl oder melde dich beim Administrator  :(");
        </script>

        <?PHP
    }
    break;

case'sammelmail':
$monat=$_SESSION['monat_id'];
 
   $sql="SELECT lehrer.wins, lehrer.email FROM lehrer, klasse LEFT JOIN abweich ON (klasse.klasse_id = abweich.klasse_id and abweich.monat_id = $monat) WHERE ((abweich.v_h IS NULL)OR(abweich.z_h IS NULL)OR(abweich.e_h IS NULL)OR(abweich.a_h IS NULL)) and klasse.lehrer_id = lehrer.lehrer_id and klasse.aktiv > 0 AND lehrer.aktiv > 0 GROUP BY lehrer.wins ORDER BY lehrer.`wins` ASC";
   $alle = $db->query($sql);

  
    foreach ($alle AS $id=>$nutzer)   // Und Zeige diese an
    { 
        $wins="$nutzer[wins]";
        $empfaenger="$nutzer[email]";
		$sql="SELECT monat FROM monat WHERE monat_id=$monat"; // von monat_id in Monatswort 
		$mo=$db->query($sql);
		$zeitraum=$mo[0][monat];   
        $link = 'http://testdev.eckener-schule.de/TMIT/alternativ/www/index.php';
        $betreff="Stundenabweichungen";
        $text= "Hallo $wins, hiermit erinnere ich Sie daran die Stundenabweichungen für Ihre Klassen im Abrechnungszeitraum $zeitraum nachzutragen.  \r\n";
        $text .="Hier ist ihr Link zum login $link ";
        $nachricht= str_replace("\n.","\n..",$text);
        $headers  = 'From: TIMT <testdev@eckener-schule.de>';
        $headers .= "Mime-Version: 1.0\r\n";
        $headers .= "Content-type: text/plain; charset=utf-8";

    
 if(mail($empfaenger, $betreff, $nachricht, $headers)==true)
        {
            
			
			$check=1;
			
			
        }
        else
        {
            
			$check=0;
			
		}
    }
	if($check==1)
	{
		?>
        <script>
            alert("Die E-Mails wurde erfolgreich versendet :)");
        </script>
        <?php
    }
	else
	{
		  ?>
        <script>
            alert("Die E-Mails konnte leider nicht versendet werden");
        </script>

        <?PHP
	}
	break;
}


?>
<!DOCTYPE html>
<html lang="de">
<head>
    <title>Verwaltung</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar-fixed-side.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
    <link href="../css/buttons.css" rel="stylesheet" />
    <link href="../css/tables.css" rel="stylesheet" />
</head>
<body>


<div class="container-fluid mantel">
    <div class="row">
        <div class="col-sm-4 col-md-3 col-lg-2">
            <nav class="navbar navbar-custom navbar-fixed-side">
                <div class="container">
                    <div class="navbar-header">
                        <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="../www/index.php" title="Zum Index">
                            <img src="../bilder/logo_RBZ.png" style="width: 80px; height: 63px;">
                            <h3>
                                Verwaltung
                            </h3>
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="">
                        <ul class="nav navbar-nav">
                            <li class="">
                                <a href="admindex.php"><span class="glyphicon glyphicon-calendar"></span> Abweichung</a>
                            </li>
                            <li class="">
                                <a href="lehrer_verwalten.php"><span class="glyphicon glyphicon-user"></span> Lehrer verwalten</a>
                            </li>
                            <li class="">
                                <a href="klassen_verwalten.php"><span class="glyphicon glyphicon-education"></span> Klassen verwalten</a>
                            </li>
                            <li class="active">
                                <a href="uebersicht.php"><span class="glyphicon glyphicon-list"></span> Übersicht</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <div class="col-sm-8 col-lg-10">
            <div class="row">

                <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                    <h1>
                        Administration
                        <br>
                        <small>
                            Übersicht
                        </small>
                    </h1>

                </div>
                <div class="col-lg-2 col-md-3 col-lg-offset-1 btn-abs col-sm-4 col-xs-12">
                    <a class="btn btn-primary btn-sm sharp btn-block top-buffer" href="../www/logout.php">Logout</a>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-lg-7 border-right">
                    <div class="row">
                        <div class="col-lg-4 col-sm-10">
                            <?php $monat=monat("uebersicht.php");
					
								
							?>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-12">
                            <h2>Summe Abweichungen</h2>
                            <table class="minimalist-b" style="width: 20rem">
                                <tr>
                                    <th>V</th>
                                    <th>Z</th>
                                    <th>E</th>
                                    <th>A</th>
                                </tr>

                                <?php 
                                $sql = "SELECT SUM(v_h) AS `v_h`, SUM(`z_h`) AS `z_h`,SUM(e_h) AS `e_h`, SUM(`a_h`) AS `a_h` FROM `abweich` WHERE monat_id=$monat";
                                $einzel_sum = $db->query($sql);

                                foreach ($einzel_sum AS $id=>$a)
                                {
                                    if($a['v_h']==NULL)
                                    {
                                        $v_h="Leer";
                                    }else{
                                        $v_h="$a[v_h]";
                                    }

                                    if($a['z_h']==NULL)
                                    {
                                        $z_h="Leer";
                                    }else{
                                        $z_h="$a[z_h]";
                                    }

                                    if($a['e_h']==NULL)
                                    {
                                        $e_h="Leer";
                                    }else{
                                        $e_h="$a[e_h]";
                                    }

                                    if($a['a_h']==NULL)
                                    {
                                        $a_h="Leer";
                                    }else{
                                        $a_h="$a[a_h]";
                                    }

                                    echo'
                                    <tr>
                                        <td>'.$v_h.'</td>
                                        <td>'.$z_h.'</td>
                                        <td>'.$e_h.'</td>
				                        <td>'.$a_h.'</td>
				                    </tr>';
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-12">

                            <h2>Lehrer mit fehlenden Einträge</h2>
	
                           <form ="uebersicht.php" form method="post">
								<input type = "hidden" name="formaction" value="sammelmail">
                                <input type= submit class="btn btn-primary btn-sm sharp" value="Alle Benachrichtigen">
                            </form>

                            <table class="table table-hover top-buffer">
                             
							 <tr>
                                    <th>Lehrer</th>
                                    <th>Email</th>
                                    <th>Email senden</th>
                                </tr>
                                <?php

                                $sql="SELECT lehrer.wins, lehrer.email FROM lehrer, klasse LEFT JOIN abweich ON (klasse.klasse_id = abweich.klasse_id and abweich.monat_id = $monat) WHERE ((abweich.v_h IS NULL)OR(abweich.z_h IS NULL)OR(abweich.e_h IS NULL)OR(abweich.a_h IS NULL)) and klasse.lehrer_id = lehrer.lehrer_id and klasse.aktiv > 0 AND lehrer.aktiv > 0 GROUP BY lehrer.wins ORDER BY lehrer.`wins` ASC";
                                $alle_lehrer = $db->query($sql);

                                foreach ($alle_lehrer AS $id=>$nutzer)
                                {
                                    $wins="$nutzer[wins]";
                                    $email="$nutzer[email]";

                                    echo'
                                    <tr>
                                        <td><h4>'.$wins.'</h4></td>
				                        <td>'.$email.'</td>
				                        <td>
				                            <form action="uebersicht.php" method="post">
				                                <input type = "hidden" name="empfaenger" value="'.$email.'" >
				                                <input type = "hidden" name="wins" value="'.$wins.'" >
				                                <input type = "hidden" name="Zeitraum" value="'.$monat.'" >
				                                <input type = "hidden" name="formaction" value="email">
				                                <input type = "submit" class="btn btn-primary sharp" value="Senden">
				                            </form>
				                        </td>
                                    </tr>';
                                }
                                ?>

                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2>Klassen ohne Lehrer</h2>
                            <table class="minimalist-b" style="width: 15rem; text-align: center">

                                <?php
                                foreach ($klasse AS $anzahl_klassen=>$a)
                                {
                                    $klasse="$a[klasse]";
                                    $id=$a['klasse_id'];
                                    echo"
                                    <tr>
		                                <td><a href='klassen_lehrerZuweisen.php?data%5Bid%5D=$id' style='color:#5c5c5c'>$klasse</a></td>
		                            </tr>";
                                }
                                ?>

                            </table>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-12">
                            <h2>Lehrer ohne Klassen</h2>
                            <table class="minimalist-b" style="width: 15rem; text-align: center">

                                <?php
                                foreach($unzugewieseneLehrer AS $key=>$lehrerName)
                                {
                                    $value=$lehrerName['wins'];
                                    $id=$lehrerName['lehrer_id'];
                                    echo "
                                    <tr>
                                        <td><a href='lehrer_klassenZuweisen.php?data%5Bid%5D=$id' style='color:#5c5c5c'>$value</a></td>
                                    </tr>";
                                }
                                ?>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row top-buffer-groß">
                <br>
            </div>
        </div>
    </div>
</div>


<footer class="footer">
    <div class="container-fluid">
            <?php
            $datum = date("d.m.Y H:i");
            echo"$datum";
            ?>

    </div>
</footer>

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</body>
</html>


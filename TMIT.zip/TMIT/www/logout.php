<?php
/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 20.03.17
 * Time: 21:39
 */


session_start();
session_destroy();
header('Location: index.php');
?>
<?php session_start();

/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 14.03.17
 * Time: 21:16
 */

require("../inc/includes.php");

$moodleIP="moodle2.esfl.de/moodle/";

$nachricht="<h2>Bitte melden Sie sich an</h2>";


if(isset($_POST['logintest']))
{
    $_SESSION['nutzer_wins']="kier";
    $_SESSION['nutzer_id']=22;
    header('Location: lehrerindex.php');
    exit;
}
if(isset($_POST['logintestadmin']))
{
    $_SESSION['nutzer_wins']="padmin";
    $_SESSION['nutzer_id']=1;
    $_SESSION['nutzer_level']=1;
    header('Location: ../admin/admindex.php');
    exit;
}


if(isset($_GET['code']))
{
    $code=$_GET['code'];
    $url = 'https://'.$moodleIP.'/local/oauth/token.php';
    $url2= 'https://'.$moodleIP.'/local/oauth/user_info.php';
    $fields = array(
        'code' => $code,
        'client_id' => 'PASST_TMIT',                                        //client id aus moodle
        'client_secret' => '68af2894fdfdb6607ad8a1c5b7035208c373721128e5633a',  //secret aus moodle
        'grant_type' => 'authorization_code',
        'scope' => 'user_info',
    );
    $secret = json_decode((httpPost($url, $fields)));
    $info=json_decode((httpPost($url2, $secret)), true);

    if(isset($info['email']))
    {
        $mail=$info['email'];

        $abc=explode('@',$mail);


        if(true)        //$abc[1]=='esfl.de'
        {


            global $db;
            $sql = 'SELECT * FROM lehrer WHERE lehrer.email = "'.$mail.'"';
            $result=$db->query($sql);
            if($result[0]['aktiv']==1)
            {

                $_SESSION['nutzer_wins']=$result[0]['wins'];
                $_SESSION['nutzer_id']=$result[0]['lehrer_id'];
                if($result[0]['level']==1)
                {

                    $_SESSION['nutzer_level']=$result[0]['level'];
                    header('Location: ../admin/admindex.php');
                }
                else
                {
                    header('Location: lehrerindex.php');
                }


            }
            else
            {
                $nachricht="<h2>Bitte melden Sie sich an <small>Sie wurden inaktiv geschaltet</small></h2>";
            }


        }
        else
        {
            $nachricht="<h2>Bitte melden Sie sich an <small>Sie haben keine ESFL Email</small></h2>";
        }



    }

}

?>
<!DOCTYPE html>
<html lang="de">
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar.css" type="text/css" rel="stylesheet">
    <link href="../css/navbar-fixed-side.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
    <link href="../css/buttons.css" rel="stylesheet" />
    <link href="../css/tables.css" rel="stylesheet" />
    <link href="../css/equaly-hights.css" rel="stylesheet" />
</head>
<body>


<div class="container-fluid">
    <div class="row" style="background-color: #c0c0c0">
        <div class="col-lg-1 col-md-2 col-sm-2 col-xs-5">
            <a href="./index.php" title="Zum Index">
                <img src="../bilder/logo_RBZ.png" class="center-block" style="width: 10rem; height: auto; display: block; margin-top: 1rem;">
            </a>
        </div>
        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-7">
            <h1>
                HOME
                <br>
                <small>
                    Login
                </small>
            </h1>
        </div>
        <div class="col-lg-2 col-md-3 btn-abs col-sm-3 col-xs-12">
            <div style="margin-top: 1rem">
                <form action="https://<?php echo $moodleIP;?>/local/oauth/login.php?client_id=PASST_TMIT&response_type=code" method="post" >
                    <input type="submit" class="btn btn-primary btn-sm sharp btn-block" value="Login">
                </form>
                <a style="margin-top: 1rem" class="btn btn-primary btn-sm sharp btn-block" href="http://<?php echo $moodleIP;?>/login/logout.php">Moodle-Logout</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <h2>Welcome</h2>
            <?php echo ($nachricht); ?>

            <form>
                <input type="submit" class="btn btn-primary btn-sm sharp" name="logintest" value="test login lehrer: Kier" formaction="index.php" formmethod="post">
                <input type="submit" class="btn btn-primary btn-sm sharp" name="logintestadmin" value="test login admin" formaction="index.php" formmethod="post">
            </form>
        </div>
    </div>
    <div class="row top-buffer">
        <br>
    </div>
</div>

<footer class="footer">
    <div class="container-fluid">
            <?php
            $datum = date("d.m.Y H:i");
            echo"$datum";
            ?>

    </div>
</footer>

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</body>
</html>


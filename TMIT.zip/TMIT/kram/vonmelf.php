
<?php
/**
 * Created by IntelliJ IDEA.
 * User: andreclausen
 * Date: 17.04.17
 * Time: 16:13
 */

if (isset($_GET["token"])) {
    $token = $_GET["token"];

    // verify token
    $sql = "SELECT lehrer_id, level FROM login_token WHERE token = '".$token."'";
    $row = $db -> query($sql);

    if ($row) {
        extract($row);
    }
    else {
        throw new Exception("Valid token not provided.");
        exit();
    }
    // do one-time action here, like activating a user account
    // ...

    // delete token so it can't be used again
    $sql = "DELETE FROM login_token WHERE lehrer_id = '".$row[0]['lehrer_id']."'";
    $db-> query($sql);


    //Setze Eintrag in SESSION und lösche andere Daten.
    $sql = "SELECT * FROM lehrer WHERE lehrer_id ='".$row[0]['lehrer_id']."'";
    $nutzerdaten = $db -> query($sql);



    $_SESSION['login']['lehrer_id'] = $nutzerdaten[0]['lehrer_id'];
    $_SESSION['login']['wins'] = $nutzerdaten[0]['wins'];
    $_SESSION['login']['email'] = $nutzerdaten[0]['email'];
    $_SESSION['login']['level'] = $nutzerdaten[0]['level'];
    $_SESSION['login']['aktiv'] = $nutzerdaten[0]['aktiv'];

    $row = array("");
    $token = "";
    ?><script>window.location.replace("http://testdev.eckener-schule.de/t2/www/admin_abweichung.php");</script><?php
    header("Location: http://testdev.eckener-schule.de/t2/www/admin_abweichung.php");
    die("DIEEE!");
}

//--------------------------------------------------------------------------------------

//------------Switch zur Steuerung der Formaction-Funktionen----------------------------
switch ($formaction)  // Je nach gespeichertem Befehl aus Formular eine Aktion ausführen
{   // Deaktivierungsbefehl erteilt
    case 'LoginEmail':

        //Ist die angebene Email in der Datenbank mit einem eingetragenen Lehrer verknüpft?
        global $db;
        $sql="SELECT lehrer_id, level FROM lehrer WHERE email = '".$_POST['LoginEmail']['email']."'";
        $db_result = $db -> query($sql);

        $lehrer_id = $db_result[0]['lehrer_id'];
        $level = $db_result[0]['level'];

        //Erstelle den einzigartigen Token
        $token = sha1(uniqid($lehrer_id, true));

        //Speichert den Token zur späteren nutzung in der Datenbank ab
        $sql = "INSERT INTO login_token (lehrer_id, level, token, tstamp) VALUES ('".$lehrer_id."', '".$level."', '".$token."', '".$_SERVER['REQUEST_TIME']."')";
        $db -> query($sql);

        //Erstelle Login Link mit Token
        //$loginURL = "http://localhost/wara_css/start/login.php?token=$token";
        $loginURL = "http://testdev.eckener-schule.de/t2/start/login.php?token=$token";

        //Versende Email an die durch den Nutzer angegebene Email-Adresse
        $empfaenger = $_POST["LoginEmail"]["email"];
        $betreff="Login Link";
        $text="Moin Moin, hier dein persönlicher Login-Link, er ist nur einmal gültig. <br/><br/> '".$loginURL."' <br/><br/> Vielen Dank! Schöne Grüße <br> Melf Jensen";
        $nachricht= str_replace("\n.", "\n..", $text);

        $headers = 'FROM: WARA-Team2 <testdev@eckener-schule.de>';
        $headers .= 'MIME-Version: 1.0';
        $headers .= 'Content-Type: text/html; charset= utf8' . "\r\n";


        if(mail($empfaenger, $betreff, $nachricht, $headers ) == true)
        {
            ?>
            <script>
                alert("Die E-Mail wurde erfolgreich versendet :)");
            </script>
            <?php
        }
        else
        {
            ?>
            <script>
                alert("Die E-Mail konnte leider nicht versendet werden.. \r\n Bitte kontrolliere die Eingabe oder melde dich beim Administrator  :(");
            </script>
            <?php
        }

        break;     //Raus aus Switch-Statement

}	// of switch

?>
<div class="w3-container" >
    <div class="w3-row-padding" id="loginMoodle">
        <h3> Moodle Login </h3>
        <form action="login.php" method="post" name="loginMoodle">
            <ul class="w3-ul w3-card-4 w3-white">

                <li class="w3-padding-16">
                    <p><h5><label for="emailMoodle">Mail:</label></h5></p>
                    <input type="email" id="emailMoodle" name="emailMoodle">
                    <input type="hidden" name="formaction" value="sendLoginMoodle">
                </li>

                <li class="w3-padding-16">
                    <input type="submit" class="submit_btn" value="Abschicken" onClick="if(confirm('Möchtest du dich wirklich über Moodle?'))document.loginMoodle.submit();">
                    <input type="reset" class="reset_btn" value="Reset">
                </li>
            </ul>
        </form>
    </div>
    <div class="w3-row-padding"><button id="showSendLoginEmail" class="w3-button w3-dark-grey" >LogIn via Mail</button></div>
</div>


<div class="w3-container" >
    <div class="w3-row-padding" id="sendLoginMail" style="display: hidden;">
        <h3> Login Mail </h3>
        <form action="login.php" method="post" name="LoginEmail">
            <ul class="w3-ul w3-card-4 w3-white">

                <li class="w3-padding-16">
                    <p><h5><label for="email">Mail:</label></h5></p>
                    <input type="email" id="loginEmail" name="LoginEmail[email]">
                    <input type="hidden" name="formaction" value="LoginEmail">
                </li>

                <li class="w3-padding-16">
                    <input type="submit" class="submit_btn" value="Abschicken" onClick="if(confirm('Möchtest du wirklich eine Login Email generieren?'))document.sendLoginEmail.submit();">
                    <input type="reset" class="reset_btn" value="Reset">
                </li>
            </ul>
        </form>
    </div>
</div>
<br>
<?php session_start(); ?>
<!DOCTYPE html>
<?php
/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 14.03.17
 * Time: 21:16
 */

require("../inc/includes.php");


?> 
<html lang="en">
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
    <link href="../css/test.css" type="text/css" rel="stylesheet">
</head>
<body>

<header>
    <div class="container">
        <div class="row row-eq-height">
            <div class="col-md-2">
                <a href="admindex.php">
                    <img src="../bilder/logo_RBZ.png" width="75px" class="img-responsive">
                </a>
            </div>
            <div class="col-md-8 text-center">
                <h1>
                    Eckener Schule
                </h1>
            </div>
            <div class="col-md-2">
                <form action="http://10.211.55.5/local/oauth/login.php?client_id=oauthsupertoll&response_type=code" method="post" >
                    <input type="submit" value="Login" class="btn btn-primary btn-default">
                </form>
                <a href="http://10.211.55.5/login/logout.php">
                    <button class="btn btn-primary btn-default">
                        Moodle Logout
                    </button>
                </a>
            </div>
        </div>
    </div>
</header>

<div class="container-fluid text-center">
    <div class="row content">
        <div class="col-sm-2 sidenav">
            <p><a href="admindex.php">Abweichung</a></p>
            <p><a href="lehrer.php">Lehrerverwalten</a></p>
            <p><a href="klassen.php">Klassenverwalten</a></p>
            <p><a href="auswertung.php">Auswertung</a></p>
        </div>
        <div class="col-sm-8 text-left">
            <?php 
            if (isset($_POST['formaction']))
			{
			    $formaction = $_POST["formaction"];
            }
			else
			{
			    $daten = array();
			    $formaction="";
			}	

           
	     
	
		
		if(ISSET($_POST['k_aktiv']))    							   // Anzeigen aktiv, nicht aktive Klassen
		{
			$_SESSION['k_aktiv']=$_POST['k_aktiv'];
			$klassen_filter =$_SESSION['k_aktiv'];
			
		}
		else
		{
			if(ISSET($_SESSION['k_aktiv']))
			{
				$klassen_filter =$_SESSION['k_aktiv'];
			}
			else
			{
				$klassen_filter ="2";
				$_SESSION['k_aktiv']=2;
			}
		}
		
				if(!ISSET($_GET["seite"]) || !is_numeric($_GET["seite"])) 		// Hier wird die Anzahl der Klassen ermittelt
				{
				$_GET["seite"] = 1;
				}
				global $db;
					switch($klassen_filter)
					{
						case 0:
						$sql=("SELECT COUNT(*) as anzahl FROM klasse WHERE aktiv=0");
						break;
						case 1:
						$sql=("SELECT COUNT(*) as anzahl FROM klasse WHERE aktiv=1");
						break;
						case 2:
						$sql=("SELECT COUNT(*) as anzahl FROM klasse");
						break;
					}
				$anzahl = $db->query($sql);
  
	  
			if(ISSET($_POST['pro_seite']))    							   // Einstellen wie viele Einträge pro Seite 
			{
				$_SESSION['angezeigt']=$_POST['pro_seite'];
				$eintraege_pro_seite =$_SESSION['angezeigt'];
			}
			else
			{
				if(ISSET($_SESSION['angezeigt']))
				{
					$eintraege_pro_seite =$_SESSION['angezeigt'];
				}
				else
				{
					$eintraege_pro_seite =25;
					$_SESSION['angezeigt']=25;					
				}
			}
	
  	 
			
		
?>						<!--Auswahlfeld, wie viele Einträge pro Seite -->
		<form action name="pro_seite" method="post"> 
	 
			<select onchange="document.pro_seite.submit()" size="1" name="pro_seite" >
			<option <?PHP if($_SESSION['angezeigt']==25) echo 'selected="selected"'; ?>  >25</option>	
			<option <?PHP if($_SESSION['angezeigt']==50) echo 'selected="selected"'; ?>  >50</option>	
			<option <?PHP if($_SESSION['angezeigt']==75) echo 'selected="selected"'; ?>  >75</option>	
			<option <?PHP if($_SESSION['angezeigt']==100) echo 'selected="selected"'; ?> >100</option>	
			<option <?PHP if($_SESSION['angezeigt']==200) echo 'selected="selected"'; ?> >200</option>	
			</select>
			<noscript>
			<input type="submit" value="Übernehmen"><br>
			</noscript>
		</form>

						<!-- ENDE Auswahlfeld, wie viele Einträge pro Seite -->

			
						<!--Auswahlfeld, aktiv-,nicht aktiv-, alle Klassen -->
		<form action name="k_aktiv" method="post"> 
	 
	 
	 
	 
			<select onchange="document.k_aktiv.submit()" size="1" name="k_aktiv" >
			<option <?PHP if($_SESSION['k_aktiv']==2) echo 'selected="selected"';?> value="2"  >Alle Klassen</option>	
			<option <?PHP if($_SESSION['k_aktiv']==1) echo 'selected="selected"';?>  value="1" >Aktive Klassen</option>	
			<option <?PHP if($_SESSION['k_aktiv']==0) echo 'selected="selected"'; ?>  value="0" >Nicht aktive Klassen</option>	
			
			</select>
			<noscript>
			<input type="submit" value="Übernehmen"><br>
			</noscript>
		</form>	 
	


						<!--ENDE, aktiv-,nicht aktiv-, alle KLassen -->

<?PHP  								 


	

		 
		 
            if ($anzahl[0]['anzahl']  % $eintraege_pro_seite == 0)
            {
		        $hoechst  = $anzahl / $eintraege_pro_seite ;
            }
	        else
		    {
		        $z = $anzahl[0]['anzahl']  / $eintraege_pro_seite ;
		        $hoechst= ceil($z);
            }
     
            if ($_GET["seite"] > $hoechst || $_GET["seite"] < 1)
            {
		        $_GET["seite"] = 1;
		    }
   
	        $start = $_GET["seite"] * $eintraege_pro_seite - $eintraege_pro_seite; // Festlegung des Startwertes, abwelchen Datensatz.
   
            
					switch($klassen_filter)
					{
						case 0:
							$sql = "SELECT * 
									FROM klasse 
									WHERE aktiv =0
									ORDER BY `klasse`.`klasse` ASC LIMIT $start, $eintraege_pro_seite ";			//Sql abfrage für die Tabelle (nicht aktive klassen)
							break;
						case 1:
							$sql = "SELECT * 
									FROM klasse 
									WHERE aktiv =1
									ORDER BY `klasse`.`klasse` ASC LIMIT $start, $eintraege_pro_seite ";			//Sql abfrage für die Tabelle (alle aktive klassen)
							break;
						case 2:
						$sql = "SELECT * 
									FROM klasse 
									ORDER BY `klasse`.`klasse` ASC LIMIT $start, $eintraege_pro_seite ";			//Sql abfrage für die Tabelle (alle klassen)
							break;
					}
					
	        $alle_klassen = $db->query($sql);

	        echo "<h1>Klassenverwaltung</h1>";  // Ausgabe Klassentabelle
 
	        ?>

            <div style="height:600px;overflow-y:scroll;;">
                <table class="table table-hover">
                        <tr>
                            <th>Klasse</th>
		                    <th>Sollstunden</th>
		                    <th>Aktiv</th>
                            <th></th>
		                    <th></th>
		                </tr>

                        <?php
                        foreach ($alle_klassen AS $id=>$a)
                        {
                            echo'<form action="'."Klasse_bearbeiten.php".'" method="post">	
                            <tr>';

                            $klasse="$a[klasse]";
                            $sollstd="$a[sollstunden]";
                            $aktiv="$a[aktiv]";
                            $klasse_id="$a[klasse_id]";

                            echo 	'<td>'.$klasse.'</td>
                                    <td>'.$sollstd.'</td>
                                    <td>'.$aktiv.'</td>';

                            echo 	'<td width="30%">        
                                    <input type = "hidden" name="data[id]" value="'.$klasse_id.'" >
                                    <input type="submit" class="btn btn-primary"  formaction= Klasse_bearbeiten.php formmethod="post"  value="Klasse Bearbeiten"></td>
                                    <td><input type="submit" class="btn btn-primary" formaction= lehrer_zuweisen.php formmethod="post" value="Lehrer Zuweisen">
                                    </td></tr>
                                    </form>	';
                        }

                        echo '</table>';

                        $ausgabe = "";

                        for($i=1; $i <= $hoechst; $i++)    // Hier wird die aktuelle Seite ohne link geschrieben und die anderen Seiten werden verlinkt
                        {
                             if ($_GET["seite"] == $i )
                             {
                                $ausgabe .= " $i ";
                             }
                             else
                             {
                                $ausgabe .= " <a href='" . htmlspecialchars($_SERVER["PHP_SELF"]) ."?seite=$i'>$i</a> ";
                             }
                        }
                         echo $ausgabe;
							?>
							</div>
							<br>
                        <form action>		<!--// Neue Klasse anlegen -->
	                    <input type="submit" class="btn btn-primary"  formaction= "Klasse_anlegen.php" formmethod="post"  value="Neue Klasse anlegen">
			            </form>
                        
            
        </div>
    </div>
</div>

<footer class="container-fluid text-center">
    <?php
    $datum = date("d.m.Y H:i");
    echo"$datum";
    ?>
</footer>

</body>
</html>


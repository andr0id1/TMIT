<?php session_start(); ?>
<!DOCTYPE html>
<?php
/**
 * Created by PhpStorm.
 * User: andreclausen
 * Date: 14.03.17
 * Time: 21:16
 */

require("../inc/includes.php");


?>
<html lang="en">
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../css/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
    <link href="../css/test.css" type="text/css" rel="stylesheet">
</head>
<body>

<header>
    <div class="container">
        <div class="row row-eq-height">
            <div class="col-md-2">
                <a href="admindex.php">
                    <img src="../bilder/logo_RBZ.png" width="75px" class="img-responsive">
                </a>
            </div>
            <div class="col-md-8 text-center">
                <h1>
                    Eckener Schule
                </h1>
            </div>
            <div class="col-md-2">
                <form action="http://10.211.55.5/local/oauth/login.php?client_id=oauthsupertoll&response_type=code" method="post" >
                    <input type="submit" value="Login" class="btn btn-primary btn-default">
                </form>
                <a href="http://10.211.55.5/login/logout.php">

                    <button class="btn btn-primary btn-default">
                        Moodle Logout
                    </button>
                </a>
            </div>
        </div>

    </div>
</header>

<div class="container-fluid text-center">
    <div class="row content">
        <div class="col-sm-2 sidenav">
            <p><a href="admindex.php">Abweichung</a></p>
            <p><a href="lehrer.php">Lehrerverwalten</a></p>
            <p><a href="klassen.php">Klassenverwalten</a></p>
            <p><a href="auswertung.php">Auswertung</a></p>
        </div>
        <div class="col-sm-8 text-left">
            <?PHP

    if (isset($_POST['formaction']))
	{
		$formaction = $_POST["formaction"];
	}
	else
	{
		$daten = array();
		$formaction="";
	}	

           
		
		
		
	 if(ISSET($_POST['l_aktiv']))    							   // Anzeigen: nicht aktiv-,aktiv-, Alle Lehrer
	{
		$_SESSION['l_aktiv']=$_POST['l_aktiv'];
		$lehrer_filter =$_SESSION['l_aktiv'];
	}
	else
	{
		if(ISSET($_SESSION['l_aktiv']))
		{
			$lehrer_filter =$_SESSION['l_aktiv'];
		}
		else
		{
			$lehrer_filter ="2";
			$_SESSION['l_aktiv']=2;
		}
	}
	
	if(!ISSET($_GET["seite"]) || !is_numeric($_GET["seite"])) 		// Hier wird die Anzahl eingetragener Lehrer ermittelt
	{
	$_GET["seite"] = 1;
	}
	global $db;
		switch($lehrer_filter)
			{
				case 0:
				$sql=("SELECT COUNT(*) as anzahl FROM lehrer WHERE aktiv=0");
				break;
				case 1:
				$sql=("SELECT COUNT(*) as anzahl FROM lehrer WHERE aktiv=1");
				break;
				case 2:
				$sql=("SELECT COUNT(*) as anzahl FROM lehrer");
				break;
			}
	        
		$anzahl = $db->query($sql);

	if(ISSET($_POST['pro_seite']))    							   // Einstellen wie viele Einträge pro Seite 
	{
		$_SESSION['angezeigt']=$_POST['pro_seite'];
		$eintraege_pro_seite =$_SESSION['angezeigt'];
		
	}
	else
	{
		if(ISSET($_SESSION['angezeigt']))
		{
			$eintraege_pro_seite =$_SESSION['angezeigt'];
		}
		else
		{
			$eintraege_pro_seite =25;	
			$_SESSION['angezeigt']=25;
		}
	}
		
	  
	  
  
?>   						<!--Auswahlfeld, wie viele Einträge pro Seite -->

		<form action name="pro_seite" method="post"> 
	 
			<select onchange="document.pro_seite.submit()" size="1" name="pro_seite" >
			<option <?PHP if($_SESSION['angezeigt']==25) echo 'selected="selected"'; ?>  >25</option>	
			<option <?PHP if($_SESSION['angezeigt']==50) echo 'selected="selected"'; ?>  >50</option>	
			<option <?PHP if($_SESSION['angezeigt']==75) echo 'selected="selected"'; ?>  >75</option>	
			<option <?PHP if($_SESSION['angezeigt']==100) echo 'selected="selected"'; ?> >100</option>	
			<option <?PHP if($_SESSION['angezeigt']==200) echo 'selected="selected"'; ?> >200</option>	
			</select>
			<noscript>
			<input type="submit" value="Übernehmen"><br>
			</noscript>
		</form>

							 <!-- ENDE Auswahlfeld, wie viele Einträge pro Seite -->

			
							<!--Auswahlfeld, aktiv-,nicht aktiv-, alle Lehrer -->
		<form action name="l_aktiv" method="post"> 
	 
			<select onchange="document.l_aktiv.submit()" size="1" name="l_aktiv" >
			<option <?PHP if($_SESSION['l_aktiv']==2) echo 'selected="selected"';?> value="2"  >Alle Lehrer</option>	
			<option <?PHP if($_SESSION['l_aktiv']==1) echo 'selected="selected"';?>  value="1" >Aktive Lehrer</option>	
			<option <?PHP if($_SESSION['l_aktiv']==0) echo 'selected="selected"'; ?>  value="0" >Nicht aktive Lehrer</option>	
			
			</select>
			<noscript>
			<input type="submit" value="Übernehmen"><br>
			</noscript>
		</form>	 
	


							<!--ENDE, aktiv-,nicht aktiv-, alle Lehrer -->
<?PHP     
	
			
			
            if ($anzahl[0]['anzahl'] % $eintraege_pro_seite == 0)
            {
		        $hoechst = $anzahl / $eintraege_pro_seite;
	        }
	        else
            {
                $hoechst = $anzahl[0]['anzahl'] / $eintraege_pro_seite + 1;
            }
     
            if ($_GET["seite"] > $hoechst || $_GET["seite"] < 1)
		    {
		        $_GET["seite"] = 1;
		    }
   
	        $start = $_GET["seite"] * $eintraege_pro_seite - $eintraege_pro_seite;

          
					switch($lehrer_filter)
					{
						case 0:
							$sql = "SELECT wins,level,aktiv,lehrer_id
									FROM lehrer 
									WHERE aktiv =0
									ORDER BY `lehrer`.`wins` ASC LIMIT $start, $eintraege_pro_seite ";			//Sql abfrage für die Tabelle (alle nicht aktive Lehrer)
							break;
						case 1:
							$sql = "SELECT wins,level,aktiv,lehrer_id
									FROM lehrer 
									WHERE aktiv =1
									ORDER BY `lehrer`.`wins` ASC LIMIT $start, $eintraege_pro_seite ";			//Sql abfrage für die Tabelle (alle aktive Lehrer)
							break;
						case 2:
						$sql = "SELECT wins,level,aktiv,lehrer_id
									FROM lehrer 
									ORDER BY `lehrer`.`wins` ASC LIMIT $start, $eintraege_pro_seite ";			//Sql abfrage für die Tabelle (alle Lehrer)
							break;
					}
			
			
			
					$alle_lehrer = $db->query($sql);

	       
		   echo "<h1>Lehrer verwalten</h1>"; // Ausgabe Lehrertabelle 
	
	            ?>

		<div style="height:600px;overflow-y:scroll;;">
            <table class="table table-hover">
		    <tr>
                <th>Lehrer</th>
                <th>Level</th>
                <th>Aktiv</th>
                <th></th>
                <th></th>
            </tr>

                <?php
                foreach ($alle_lehrer AS $id=>$a)
	            {
                    echo'<form action="lehrer_bearbeiten.php" method="post">';
                    echo "<tr>";
		
                    $wins="$a[wins]";
                    $level="$a[level]";
                    $aktiv="$a[aktiv]";
                    $lehrer_id="$a[lehrer_id]";
                    echo 	'
                            <td>'.$wins.'</td>
                            <td>'.$level.'</td>
                            <td>'.$aktiv.'</td>';
			
                    echo '<td width="30%">
		
                    <input type = "hidden" name="data[id]" value="'.$lehrer_id.'" >
		            <input type="submit" class="btn btn-primary"  formaction= lehrer_bearbeiten.php formmethod="post"  value="Lehrer Bearbeiten"></td>
                    <td><input type="submit" class="btn btn-primary"  formaction= Klassen_zuweisen.php formmethod="post" value="Klasse bearbeiten">
                    </td></tr>
                    </form>';
                }
				 
                echo '</table>';
                $ausgabe = "";

                for($i=1; $i <= $hoechst; $i++)     // Hier wird die aktuelle Seite ohne link geschrieben und die anderen Seiten werden verlinkt
                {
                     if ($_GET["seite"] == $i )
                     {
                       $ausgabe .= " $i ";
                     }
                     else
                     {
                       $ausgabe .= " <a href='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "?seite=$i'>$i</a> ";
                     }
                }

                echo $ausgabe;
				?>
				</div>
				<br>
                <form action>		
	            <input type="submit" class="btn btn-primary"  formaction= "lehrer_anlegen.php" formmethod="post"  value="Neuer Lehrer anlegen">   <!--//Verwiesende Seiten in formaction nachtragen-->
			    </form>

                
            
		</div>
    </div>
</div>

<footer class="container-fluid text-center">
                <?php
			  $datum = date("d.m.Y H:i");
			echo"$datum";
			  ?>
</footer>

</body>
</html>


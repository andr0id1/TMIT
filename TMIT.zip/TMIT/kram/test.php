<?php
/**
 * Created by IntelliJ IDEA.
 * User: andreclausen
 * Date: 20.04.17
 * Time: 20:34
 */

require("../inc/includes.php");

if(klasseOnOff(314))
{
    echo "gut";
}
else
{
    echo "nicht gut";
}

?>
